import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import {Colors, Metrics, GlobalStyles} from '../../theme';
import MaterialIcon from '../../components/common/MaterialIcon';

const PROFILE_SETTINGS = [
  {id: 'account', label: 'Account Details', iconName: 'account', action: 'navigate'},
  {id: 'preferences', label: 'User Preferences', iconName: 'preferences', action: 'navigate'},
  {id: 'nominee', label: 'Nominee Details', iconName: 'nominee', action: 'navigate'},
  {id: 'identity', label: 'Identity Verification', iconName: 'identity', badge: 'Start now'},
];

const APP_SETTINGS = [
  {id: 'autopay', label: 'AutoPay', iconName: 'autopay'},
  {id: 'snapsave', label: 'SnapSave', iconName: 'snapsave'},
  {id: 'saveonspend', label: 'Save on Every Spend', iconName: 'saveonspend', badge: 'Paused'},
  {id: 'activation', label: 'Activation Code', iconName: 'activation'},
  {id: 'reminder', label: 'Reminder settings', iconName: 'reminder'},
];

const ProfileScreen = ({navigation}) => {
  const userName = 'Jitendra Mandal';
  const phoneNumber = '918744090761';
  const handleItemPress = id => {
    switch (id) {
      case 'account':
        navigation.navigate('AccountDetails');
        break;
      case 'preferences':
        navigation.navigate('UserPreferences');
        break;
      case 'nominee':
        navigation.navigate('NomineeDetails');
        break;
      default:
        break;
    }
  };

  const renderItem = item => (
    <TouchableOpacity
      key={item.id}
      style={styles.menuItem}
      onPress={() => handleItemPress(item.id)}
      activeOpacity={0.6}>
      <View style={styles.menuItemLeft}>
        <View style={styles.menuIconWrap}>
          <MaterialIcon name={item.iconName} size={24} color={Colors.primary} />
        </View>
        <Text style={styles.menuItemLabel}>{item.label}</Text>
      </View>
      {item.badge ? (
        <Text
          style={[
            styles.badge,
            item.badge === 'Start now' && styles.badgeAction,
            item.badge === 'Paused' && styles.badgePaused,
          ]}>
          {item.badge}
        </Text>
      ) : (
        <Text style={styles.chevron}>›</Text>
      )}
    </TouchableOpacity>
  );

  return (
    <View style={GlobalStyles.containerWhite}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn} activeOpacity={0.7}>
          <Text style={styles.backArrow}>←</Text>
        </TouchableOpacity>
        <View style={{flex: 1}} />
        <TouchableOpacity activeOpacity={0.7}>
          <MaterialIcon name="help" size={22} color={Colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        bounces={false}>
        {/* Profile Avatar */}
        <View style={styles.avatarSection}>
          <View style={styles.avatar}>
            <MaterialIcon name="person" size={44} color={Colors.primary} />
          </View>
          <Text style={styles.userName}>{userName}</Text>
          <Text style={styles.userPhone}>{phoneNumber}</Text>
          <Text style={styles.userMeta}>Age 30  Joined March 2026</Text>
        </View>

        {/* Profile Settings */}
        <Text style={styles.sectionTitle}>Profile Settings</Text>
        {PROFILE_SETTINGS.map(renderItem)}

        {/* App Settings */}
        <Text style={[styles.sectionTitle, {marginTop: Metrics.spacing.lg}]}>
          App Settings
        </Text>
        {APP_SETTINGS.map(renderItem)}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Metrics.spacing.lg,
    paddingHorizontal: Metrics.spacing.lg,
    paddingBottom: Metrics.spacing.sm,
  },
  backBtn: {
    padding: Metrics.spacing.xs,
  },
  backArrow: {
    fontSize: 22,
    color: Colors.text,
    fontWeight: '700',
  },
  helpIcon: {
    fontSize: 20,
    color: Colors.primary,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: Metrics.spacing.lg,
    paddingBottom: 40,
  },
  /* Avatar */
  avatarSection: {
    alignItems: 'center',
    marginBottom: Metrics.spacing.xl,
    marginTop: Metrics.spacing.md,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8E8E8',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Metrics.spacing.md,
  },
  avatarEmoji: {
    fontSize: 40,
  },
  userName: {
    fontSize: Metrics.fontSize.title,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 4,
  },
  userPhone: {
    fontSize: Metrics.fontSize.medium,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  userMeta: {
    fontSize: Metrics.fontSize.small,
    color: Colors.textSecondary,
    fontStyle: 'italic',
  },
  /* Sections */
  sectionTitle: {
    fontSize: Metrics.fontSize.body,
    fontWeight: '800',
    color: Colors.text,
    marginBottom: Metrics.spacing.sm,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Metrics.spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EEEEEE',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuIconWrap: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Metrics.spacing.md,
  },
  menuIcon: {
    fontSize: 20,
  },
  menuItemLabel: {
    fontSize: Metrics.fontSize.body,
    fontWeight: '500',
    color: Colors.text,
    flex: 1,
  },
  chevron: {
    fontSize: 22,
    color: Colors.primary,
    fontWeight: '300',
  },
  badge: {
    fontSize: Metrics.fontSize.small,
    fontWeight: '600',
  },
  badgeAction: {
    color: Colors.primary,
  },
  badgePaused: {
    color: Colors.textSecondary,
    fontStyle: 'italic',
  },
});

export default ProfileScreen;
